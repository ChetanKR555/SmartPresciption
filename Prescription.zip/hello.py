"""
* project name: smart medical prescription assistant
* authors list: vignesh,shashank,sharmeen,tulsi
* filename: hello.py
* functions: index,getSymptom,getDrug
* global variables:NONE

"""

import csv
import pandas as pd
import numpy as np
from collections import defaultdict
import seaborn as sns
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression


from flask import Flask,render_template,request
app = Flask(__name__,static_url_path='')

"""
* function name: index
* input: NONE
* output: html template for entering symptoms
* logic: through flask python code is loaded and html template is called
* example call: render_template('filename');

"""
@app.route("/")
def index():
    return render_template('index.html')

#d disease detected
d=""
#disease various list of diseases
diseases=[]
ind=0

"""

*function:getSymptom
*input:various diseases symptoms from raw_data csv file
*output:from symptoms relavent disease is predicted and corresponding template is outputed
*logic:symptoms are matched to disease and most appropriate is outputed
*example:symptom such as[vertigo,polyuria,chest pain,etc]

"""


@app.route('/getSymptom',methods=['POST'])
def getSymptom():
    d_symptom = request.form['symptom']
    print(d_symptom)

    #processing the data
    def process_data(data):
        data_list = []
        data_name = data.replace('^','_').split('_')
        n = 1
        for names in data_name:
            if (n % 2 == 0):
                data_list.append(names)
            n += 1
        return data_list

    df = pd.read_excel('raw_data.xlsx')
    data = df.fillna(method='ffill')
    disease_list = []
    disease_symptom_dict = defaultdict(list)
    disease_symptom_count = {}
    count = 0

    for idx, row in data.iterrows():
        
        # Get the Disease Names
        if (row['Disease'] !="\xc2\xa0") and (row['Disease'] != ""):
            disease = row['Disease']
            disease_list = process_data(data=disease)
            count = row['Count of Disease Occurrence']

        # Get the Symptoms Corresponding to Diseases
        if (row['Symptom'] !="\xc2\xa0") and (row['Symptom'] != ""):
            symptom = row['Symptom']
            symptom_list = process_data(data=symptom)
            for d in disease_list:
                for s in symptom_list:
                    disease_symptom_dict[d].append(s)
                disease_symptom_count[d] = count

    df1 = pd.DataFrame(list(disease_symptom_dict.items()), columns=['Disease','Symptom'])

    l=df1['Symptom'].tolist()
    x=df1['Disease'].tolist()
    
    disease_sc=[]
    user_symptom = d_symptom
    user_symptom=user_symptom.strip()
    arr=user_symptom.split(',')
    for symp in arr:
        print(symp)
        cnt=-1
        for b in l:
            #print(b)
            
            cnt=cnt+1
            for a in b:
                if symp in a:               
                    diseases.append(x[cnt])
                    disease_sc.append(disease_symptom_count[x[cnt]])
                    
    print(diseases)
    ind=disease_sc.index(max(disease_sc))

    
    d=diseases[ind]
    print(d)
    return render_template(d+'.html')
"""

*function name:getDrug
*input:diagnestic data of relavent disease
*output:appropriate drug for disease
*logic:linear regression
*example:various enties[pregnancies,age,sex,SP,DP,etc]

"""
@app.route('/getDrug',methods=['POST'])
def getDrug():
    d=request.form['d']    
    if('hyper' in d):
        drugs1=["angiotensin converting enzyme inhibitors","Vasodilators","ARB","Thiazide"]
        drugs2=["Aldostereone","Central Acting Agents","Renin"]
        drugs3=["Beta Blockers","Calcium Channel Blockers"]
        cdrug=drugs1+drugs2+drugs3
        dataset=pd.read_csv('hypt actual.csv')
        (rows,cols)=dataset.shape

        X=pd.DataFrame(dataset.iloc[:rows-1,:-1])
        y=pd.DataFrame(dataset.iloc[:rows-1,-1])


        X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.1, random_state=0)

        X_test=X_test.append(pd.DataFrame(dataset.iloc[rows-1:,:-1]))
        y_test=y_test.append(pd.DataFrame(dataset.iloc[rows-1:,-1]))
                      
        regressor=LinearRegression()
        regressor.fit(X_train,y_train)
        v=pd.DataFrame(regressor.coef_,index=['Co-efficient']).transpose()
        w=pd.DataFrame(X.columns,columns=['Attribute'])
        coeff_df=pd.concat([w,v],axis=1,join='inner')



        y_pred=regressor.predict(X_test)
        y_pred=pd.DataFrame(y_pred,columns=['Predicted'])
        #print(y_test)
        #print(y_pred)
        (r,c)=y_pred.shape
        n=int(y_pred.iloc[r-1,0])
        #print('Drug prediction', cdrug[n])

        return cdrug[n]
        #return render_template('output.html')

        

        
    elif('diabetes' in d):
        drugs1=["Admelog","Humalog,U-100,U-200","Apidra","Fiasp","Novolog"]
        drugs2=["Regular","U-500(5x the concentration)","NPH"]
        drugs3=["Basaglar","Lantus","Levemir","Toujeo"]
        cdrug=drugs1+drugs2+drugs3
        dataset=pd.read_csv('diabetes.csv')
        (rows,cols)=dataset.shape
        
        X=pd.DataFrame(dataset.iloc[:rows-1,:-1])
        y=pd.DataFrame(dataset.iloc[:rows-1,-1])
        
        
        X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.1, random_state=0)
        
        X_test=X_test.append(pd.DataFrame(dataset.iloc[rows-1:,:-1]))
        y_test=y_test.append(pd.DataFrame(dataset.iloc[rows-1:,-1]))
                      
        regressor=LinearRegression()
        regressor.fit(X_train,y_train)
        v=pd.DataFrame(regressor.coef_,index=['Co-efficient']).transpose()
        w=pd.DataFrame(X.columns,columns=['Attribute'])
        coeff_df=pd.concat([w,v],axis=1,join='inner')
        
        
        
        y_pred=regressor.predict(X_test)
        y_pred=pd.DataFrame(y_pred,columns=['Predicted'])
        #print(y_test)
        #print(y_pred)
        (r,c)=y_pred.shape
        n=int(y_pred.iloc[r-1,0])
        #print('Drug prediction', cdrug[n])

        return(cdrug[n])
        #return render_template('output.html')

         
    elif('coronary' in d):
        drugs1=["Admelog","Humalog,U-100,U-200","Apidra","Fiasp","Novolog"]
        drugs2=["Regular","U-500(5x the concentration)","NPH"]
        drugs3=["Basaglar","Lantus","Levemir","Toujeo"]
        cdrug=drugs1+drugs2+drugs3
        dataset=pd.read_csv('heart.csv')
        (rows,cols)=dataset.shape
        
        X=pd.DataFrame(dataset.iloc[:rows-1,:-1])
        y=pd.DataFrame(dataset.iloc[:rows-1,-1])
        
        
        X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.1, random_state=0)
        
        X_test=X_test.append(pd.DataFrame(dataset.iloc[rows-1:,:-1]))
        y_test=y_test.append(pd.DataFrame(dataset.iloc[rows-1:,-1]))
                      
        regressor=LinearRegression()
        regressor.fit(X_train,y_train)
        v=pd.DataFrame(regressor.coef_,index=['Co-efficient']).transpose()
        w=pd.DataFrame(X.columns,columns=['Attribute'])
        coeff_df=pd.concat([w,v],axis=1,join='inner')
        
        
        
        y_pred=regressor.predict(X_test)
        y_pred=pd.DataFrame(y_pred,columns=['Predicted'])
        #print(y_test)
        #print(y_pred)
        (r,c)=y_pred.shape
        n=int(y_pred.iloc[r-1,0])
        print('Drug prediction', cdrug[n])

        return(cdrug[n])
        #return render_template('output.html')


if __name__ == "__main__":
    app.debug = True
    app.run()
    app.run(debug = True)
